//
//  main.m
//  XGTESTPROGRAM
//
//  Created by 顾九针 on 2018/10/17.
//  Copyright © 2018 顾九针. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
